var lang = 'en';

// Screen resolution comments/descriptions
var res_desc = new Object();
res_desc["320x240"] = "older handheld devices.";
res_desc["240x320"] = "older handheld devices, portrait mode.";
res_desc["320x396"] = "The iPod Touch is 320x480, but only part of the screen is available for the web browser.";
res_desc["480x320"] = "handheld devices (iPod Touch).";
res_desc["640x480"] = "handheld devices; not very common.";
res_desc["800x600"] = "not common for LCD screens, may not be the native resolution of your monitor.";
res_desc["800x480"] = "Portable devices; Asus Eee PC.";
res_desc["1024x768"] = "Older 14-15 inch screens.";
res_desc["1152x864"] = "not common for LCD screens, may not be the native resolution of your monitor.";
res_desc["1280x1024"] = "older screens and low-end new screens.";
res_desc["1280x720"] = "HDTV format, not common for computer monitors.";
res_desc["1280x768"] = "widescreen format, mainly TV sets, may not be the native resolution of your monitor";
res_desc["1280x800"] = "small widescreen format, mainly laptops and tablets.";
res_desc["1280x854"] = "only used on Mac Powerbook G4.";
res_desc["1280x960"] = "not common for LCD screens, may be not be the native resolution of your monitor.";
res_desc["1360x768"] = "common widescreen LCD TV format, may not be the native resolution of your monitor.";
res_desc["1366x768"] = "common resolution for small laptops."; // upd
//res_desc["1440x900"] = "common widescreen format.";
res_desc["1400x1050"] = "some older 4:3 monitors and high-end laptops.";
res_desc["1600x1200"] = "common format for older high-end monitors.";
res_desc["1680x1050"] = "common large widescreen format for older monitors.";
res_desc["1920x1080"] = "most common resolution for recent monitors";  // upd
// res_desc["1920x1200"] = "";
res_desc["2560x1080"] = "less common 21:9 format";
res_desc["2560x1600"] = "high-end large widescreen format.";
res_desc["2560x1440"] = "common high-end format";
res_desc["3440x1440"] = "common high-end format";
res_desc["3840x2160"] = "Most common 4K format";

// Screen resolution other messages
res_msg = new Object();
res_msg['lowres'] = "Note: your screen is too small to display the images without rescaling." +
       " (at least 1024x768 recommended)";
res_msg['uncommon'] = "Note: monitors for this resolution are uncommon; the resolution may not match the native"+
       " resolution of your monitor.";
res_msg['uncommon ratio'] = "Note: your resolution does not have a common "+
    "4:3 (1.33), 16:9 (1.78), or 21:9 (2.33) aspect ratio, which means that images can be distorted."+
    " Your aspect ratio is: ";
res_msg['portrait'] = 'Your monitor seems to be in portrait mode. A number of fine-pattern ' +
    'test images require your monitor to be in landscape mode. Please rotate your screen.';
res_msg['this test portrait'] = 'Warning: this test image may not be meaningful for screens in portrait orientation.';
res_msg['8bpp'] = '256 indexed colors';
res_msg['16bpp'] = 'Highcolor, Thousands of colors';
res_msg['24bpp'] = 'Truecolor, Millions of colors';
res_msg['bppwarning'] = 'Note: for these tests to work optimally, your color depth should be 24 or 32 bits.';
res_msg['resolution'] = 'Resolution';
res_msg['description'] = 'Description';
res_msg['color depth'] = 'Color depth';
res_msg['bits'] = 'bits'; // plural of 'bit'
res_msg['unknown'] = 'unknown';

function resmsg_as_of(year) {
    return 'as of ' + year;
}
function resmsg_bits(n) {
    return '' + n + ' bits';
}

// response time
rt_msg = new Object();
rt_msg['stop test'] = 'Stop test';

